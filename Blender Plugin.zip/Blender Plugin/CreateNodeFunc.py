import bpy;
from . BasicFunc import node_group_exists

def CreateMathNode(main_node, location, operation):
    m_node = main_node.nodes.new('ShaderNodeMath');
    m_node.location = location;
    m_node.hide = True;
    m_node.operation = operation;

    return m_node;

def GetSocketByName(socks, name):
    for socket in socks:
        if socket.name == name:
            return socket;

    return None;

def Create_SM_GlassTex_NodeGroup():
    if node_group_exists('SM Glass Tex'):
        return;

    print("Adding a glass tex node");

    SM_Glass = bpy.data.node_groups.new('SM Glass Tex', 'ShaderNodeTree');
    SM_Glass.inputs.new('NodeSocketColor', 'Diffuse');
    _dif_alpha = SM_Glass.inputs.new('NodeSocketFloatFactor', 'Diffuse Alpha');
    _dif_alpha.default_value = 0.5;
    SM_Glass.inputs.new('NodeSocketColor', 'Diffuse Color');
    _asg_col = SM_Glass.inputs.new('NodeSocketColor', 'Asg');
    _asg_col.default_value[0] = 0.5;
    _asg_col.default_value[1] = 0.5;
    _asg_col.default_value[2] = 0.5;
    _asg_col.default_value[3] = 1.0;
    _asg_alpha = SM_Glass.inputs.new('NodeSocketFloat', 'Asg Alpha');
    _asg_alpha.default_value = 0.5;
    _rough_mul = SM_Glass.inputs.new('NodeSocketFloat', 'Roughness Multiplier');
    _rough_mul.default_value = 0.5;
    _ior = SM_Glass.inputs.new('NodeSocketFloat', 'IOR');
    _ior.default_value = 1.45;
    _nor_tex = SM_Glass.inputs.new('NodeSocketColor', 'Normal');
    _nor_tex.default_value[0] = 0.5;
    _nor_tex.default_value[1] = 0.5;
    _nor_tex.default_value[2] = 1.0;
    _nor_tex.default_value[3] = 1.0;
    _nor_str = SM_Glass.inputs.new('NodeSocketFloat', 'Normal Strength');
    _nor_str.default_value = 1.0;

    SM_Glass.outputs.new('NodeSocketShader', 'BSDF');

    group_input = SM_Glass.nodes.new('NodeGroupInput');
    group_input.location = (-590, 34);

    gl_bsdf = SM_Glass.nodes.new('ShaderNodeBsdfGlass');
    gl_bsdf.location = (119, 36);
    SM_Glass.links.new(group_input.outputs[6], gl_bsdf.inputs[2]);

    mix_rgb = SM_Glass.nodes.new('ShaderNodeMixRGB');
    mix_rgb.location = (-226, -13);
    mix_rgb.hide = True;
    SM_Glass.links.new(group_input.outputs[0], mix_rgb.inputs[2]);
    SM_Glass.links.new(group_input.outputs[1], mix_rgb.inputs[0]);
    SM_Glass.links.new(group_input.outputs[2], mix_rgb.inputs[1]);
    SM_Glass.links.new(mix_rgb.outputs[0], gl_bsdf.inputs[0]);

    math1 = CreateMathNode(SM_Glass, (-43, -78), 'MULTIPLY');
    SM_Glass.links.new(group_input.outputs[5], math1.inputs[1]);
    SM_Glass.links.new(math1.outputs[0], gl_bsdf.inputs[1]);

    math2 = CreateMathNode(SM_Glass, (-199, -59), 'MULTIPLY');
    SM_Glass.links.new(group_input.outputs[4], math2.inputs[1]);
    SM_Glass.links.new(math2.outputs[0], math1.inputs[0]);

    nor_tex = SM_Glass.nodes.new('ShaderNodeNormalMap');
    nor_tex.location = (-188, -136);
    SM_Glass.links.new(group_input.outputs[7], nor_tex.inputs[1]);
    SM_Glass.links.new(group_input.outputs[8], nor_tex.inputs[0]);
    SM_Glass.links.new(nor_tex.outputs[0], gl_bsdf.inputs[3]);

    separate_rgb = SM_Glass.nodes.new('ShaderNodeSeparateRGB');
    separate_rgb.location = (-376, -53);
    SM_Glass.links.new(group_input.outputs[3], separate_rgb.inputs[0]);
    SM_Glass.links.new(separate_rgb.outputs[1], math2.inputs[0]);

    group_output = SM_Glass.nodes.new('NodeGroupOutput');
    group_output.location = (315, 30);
    SM_Glass.links.new(gl_bsdf.outputs[0], group_output.inputs[0]);

def create_SM_TEX_node_group(name, alpha):
    if node_group_exists(name):
        return;

    print("Adding", name, "node");

    SM_Tex = bpy.data.node_groups.new(name, 'ShaderNodeTree');
    SM_Tex.inputs.new('NodeSocketColor', 'Diffuse');
    _diffuse = SM_Tex.inputs.new('NodeSocketFloatFactor', 'Diffuse Alpha');
    _diffuse.default_value = 0.5;
    SM_Tex.inputs.new('NodeSocketColor', 'Diffuse Color');
    _asg_tex = SM_Tex.inputs.new('NodeSocketColor', 'Asg');
    _asg_tex.default_value[0] = 0.5;
    _asg_tex.default_value[1] = 0.5;
    _asg_tex.default_value[2] = 0.5;
    _asg_tex.default_value[3] = 1.0;
    _asg_alpha = SM_Tex.inputs.new('NodeSocketFloat', 'Asg Alpha');
    _asg_alpha.default_value = 0.5;
    _spec_mul = SM_Tex.inputs.new('NodeSocketFloat', 'Specular Multiplier');
    _spec_mul.default_value = 1.0;
    _glow_mul = SM_Tex.inputs.new('NodeSocketFloat', 'Glow Multiplier');
    _glow_mul.default_value = 1.0;
    _normal_tex = SM_Tex.inputs.new('NodeSocketColor', 'Normal');
    _normal_tex.default_value[0] = 0.5;
    _normal_tex.default_value[1] = 0.5;
    _normal_tex.default_value[2] = 1.0;
    _normal_tex.default_value[3] = 1.0;
    SM_Tex.outputs.new('NodeSocketShader', 'BSDF');
    
    group_input = SM_Tex.nodes.new('NodeGroupInput');
    group_input.location = (-500, 0);

    bsdf = SM_Tex.nodes.new('ShaderNodeBsdfPrincipled');
    bsdf.location = (152, -5);

    mix_rgb = SM_Tex.nodes.new('ShaderNodeMixRGB');
    mix_rgb.location = (-198, -47);
    mix_rgb.hide = True;
    SM_Tex.links.new(group_input.outputs[0], mix_rgb.inputs[2]);
    SM_Tex.links.new(group_input.outputs[1], mix_rgb.inputs[0]);
    SM_Tex.links.new(group_input.outputs[2], mix_rgb.inputs[1]);
    SM_Tex.links.new(mix_rgb.outputs[0], bsdf.inputs[0]);
    SM_Tex.links.new(mix_rgb.outputs[0], bsdf.inputs[19]);

    separate_rgb = SM_Tex.nodes.new('ShaderNodeSeparateRGB');
    separate_rgb.location = (-280, -100);
    SM_Tex.links.new(group_input.outputs[3], separate_rgb.inputs[0]);

    math1 = CreateMathNode(SM_Tex, (-100, -235), 'MULTIPLY');
    SM_Tex.links.new(group_input.outputs[5], math1.inputs[1]);
    SM_Tex.links.new(separate_rgb.outputs[1], math1.inputs[0]);
    SM_Tex.links.new(math1.outputs[0], bsdf.inputs[7]);


    math2 = CreateMathNode(SM_Tex, (-100, -273), 'MULTIPLY');
    SM_Tex.links.new(group_input.outputs[6], math2.inputs[1]);
    SM_Tex.links.new(separate_rgb.outputs[2], math2.inputs[0]);
    SM_Tex.links.new(math2.outputs[0], bsdf.inputs[20]);

    if alpha:
        math3 = CreateMathNode(SM_Tex, (-300, -280), 'SUBTRACT');
        math3.inputs[0].default_value = 1.0;
        SM_Tex.links.new(group_input.outputs[4], math3.inputs[1]);

        clamp1 = SM_Tex.nodes.new('ShaderNodeClamp');
        clamp1.location = (-130, -315);
        clamp1.hide = True;
        clamp1.inputs[1].default_value = 0.0;
        clamp1.inputs[2].default_value = 1.0;
        SM_Tex.links.new(math3.outputs[0], clamp1.inputs[0]);
        SM_Tex.links.new(clamp1.outputs[0], bsdf.inputs[21]);

    normal_map = SM_Tex.nodes.new('ShaderNodeNormalMap');
    normal_map.location = (-300, -315);
    SM_Tex.links.new(group_input.outputs[7], normal_map.inputs[1]);
    SM_Tex.links.new(normal_map.outputs[0], bsdf.inputs[22]);

    group_output = SM_Tex.nodes.new('NodeGroupOutput');
    group_output.location = (500, 0);
    SM_Tex.links.new(bsdf.outputs[0], group_output.inputs[0]);

def Add_SM_Nodes():
    create_SM_TEX_node_group('SM Tex', False);
    create_SM_TEX_node_group('SM Tex Alpha', True);

    Create_SM_GlassTex_NodeGroup();