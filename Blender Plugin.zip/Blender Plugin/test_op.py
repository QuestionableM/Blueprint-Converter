import bpy;

from uuid import UUID;

def is_color_valid(hex_string):
    try:
        int(hex_string, 16);
    except:
        return False;

    return True;

def is_uuid_valid(uuid_string):
    try:
        uuid_obj = UUID(uuid_string, version=4);
    except:
        return False;

    return str(uuid_obj) == uuid_string;

def is_material_valid(mat_name):
    if len(mat_name) >= 43:
        mat_color = mat_name[37:43];

        return is_color_valid(mat_color);

    return False;

def create_SM_Glass_Tex_node_group():
    SM_Glass = bpy.data.node_groups.new('SM Glass Tex', 'ShaderNodeTree');
    SM_Glass.inputs.new('NodeSocketColor', 'Diffuse');
    _dif_alpha = SM_Glass.inputs.new('NodeSocketFloatFactor', 'Diffuse Alpha');
    _dif_alpha.default_value = 0.5;
    SM_Glass.inputs.new('NodeSocketColor', 'Diffuse Color');
    _asg_col = SM_Glass.inputs.new('NodeSocketColor', 'Asg');
    _asg_col.default_value[0] = 0.5;
    _asg_col.default_value[1] = 0.5;
    _asg_col.default_value[2] = 0.5;
    _asg_col.default_value[3] = 1.0;
    _asg_alpha = SM_Glass.inputs.new('NodeSocketFloat', 'Asg Alpha');
    _asg_alpha.default_value = 0.5;
    _rough_mul = SM_Glass.inputs.new('NodeSocketFloat', 'Roughness Multiplier');
    _rough_mul.default_value = 0.5;
    _ior = SM_Glass.inputs.new('NodeSocketFloat', 'IOR');
    _ior.default_value = 1.45;
    _nor_tex = SM_Glass.inputs.new('NodeSocketColor', 'Normal');
    _nor_tex.default_value[0] = 0.5;
    _nor_tex.default_value[1] = 0.5;
    _nor_tex.default_value[2] = 1.0;
    _nor_tex.default_value[3] = 1.0;
    _nor_str = SM_Glass.inputs.new('NodeSocketFloat', 'Normal Strength');
    _nor_str.default_value = 1.0;

    SM_Glass.outputs.new('NodeSocketShader', 'BSDF');

    group_input = SM_Glass.nodes.new('NodeGroupInput');
    group_input.location = (-590, 34);

    gl_bsdf = SM_Glass.nodes.new('ShaderNodeBsdfGlass');
    gl_bsdf.location = (119, 36);
    SM_Glass.links.new(group_input.outputs[6], gl_bsdf.inputs[2]);

    mix_rgb = SM_Glass.nodes.new('ShaderNodeMixRGB');
    mix_rgb.location = (-226, -13);
    mix_rgb.hide = True;
    SM_Glass.links.new(group_input.outputs[0], mix_rgb.inputs[2]);
    SM_Glass.links.new(group_input.outputs[1], mix_rgb.inputs[0]);
    SM_Glass.links.new(group_input.outputs[2], mix_rgb.inputs[1]);
    SM_Glass.links.new(mix_rgb.outputs[0], gl_bsdf.inputs[0]);

    math1 = SM_Glass.nodes.new('ShaderNodeMath');
    math1.location = (-43, -78);
    math1.hide = True;
    math1.operation = 'MULTIPLY';
    SM_Glass.links.new(group_input.outputs[5], math1.inputs[1]);
    SM_Glass.links.new(math1.outputs[0], gl_bsdf.inputs[1]);

    math2 = SM_Glass.nodes.new('ShaderNodeMath');
    math2.location = (-199, -59);
    math2.hide = True;
    math2.operation = 'MULTIPLY';
    SM_Glass.links.new(group_input.outputs[4], math2.inputs[1]);
    SM_Glass.links.new(math2.outputs[0], math1.inputs[0]);

    nor_tex = SM_Glass.nodes.new('ShaderNodeNormalMap');
    nor_tex.location = (-188, -136);
    SM_Glass.links.new(group_input.outputs[7], nor_tex.inputs[1]);
    SM_Glass.links.new(group_input.outputs[8], nor_tex.inputs[0]);
    SM_Glass.links.new(nor_tex.outputs[0], gl_bsdf.inputs[3]);

    separate_rgb = SM_Glass.nodes.new('ShaderNodeSeparateRGB');
    separate_rgb.location = (-376, -53);
    SM_Glass.links.new(group_input.outputs[3], separate_rgb.inputs[0]);
    SM_Glass.links.new(separate_rgb.outputs[1], math2.inputs[0]);

    group_output = SM_Glass.nodes.new('NodeGroupOutput');
    group_output.location = (315, 30);
    SM_Glass.links.new(gl_bsdf.outputs[0], group_output.inputs[0]);

def create_SM_TEX_node_group(name, alpha):
    SM_Tex = bpy.data.node_groups.new(name, 'ShaderNodeTree');
    SM_Tex.inputs.new('NodeSocketColor', 'Diffuse');
    _diffuse = SM_Tex.inputs.new('NodeSocketFloatFactor', 'Diffuse Alpha');
    _diffuse.default_value = 0.5;
    SM_Tex.inputs.new('NodeSocketColor', 'Diffuse Color');
    _asg_tex = SM_Tex.inputs.new('NodeSocketColor', 'Asg');
    _asg_tex.default_value[0] = 0.5;
    _asg_tex.default_value[1] = 0.5;
    _asg_tex.default_value[2] = 0.5;
    _asg_tex.default_value[3] = 1.0;
    _asg_alpha = SM_Tex.inputs.new('NodeSocketFloat', 'Asg Alpha');
    _asg_alpha.default_value = 0.5;
    _spec_mul = SM_Tex.inputs.new('NodeSocketFloat', 'Specular Multiplier');
    _spec_mul.default_value = 1.0;
    _glow_mul = SM_Tex.inputs.new('NodeSocketFloat', 'Glow Multiplier');
    _glow_mul.default_value = 1.0;
    _normal_tex = SM_Tex.inputs.new('NodeSocketColor', 'Normal');
    _normal_tex.default_value[0] = 0.5;
    _normal_tex.default_value[1] = 0.5;
    _normal_tex.default_value[2] = 1.0;
    _normal_tex.default_value[3] = 1.0;
    SM_Tex.outputs.new('NodeSocketShader', 'BSDF');
    
    group_input = SM_Tex.nodes.new('NodeGroupInput');
    group_input.location = (-500, 0);

    bsdf = SM_Tex.nodes.new('ShaderNodeBsdfPrincipled');
    bsdf.location = (152, -5);

    mix_rgb = SM_Tex.nodes.new('ShaderNodeMixRGB');
    mix_rgb.location = (-198, -47);
    mix_rgb.hide = True;
    SM_Tex.links.new(group_input.outputs[0], mix_rgb.inputs[2]);
    SM_Tex.links.new(group_input.outputs[1], mix_rgb.inputs[0]);
    SM_Tex.links.new(group_input.outputs[2], mix_rgb.inputs[1]);
    SM_Tex.links.new(mix_rgb.outputs[0], bsdf.inputs[0]);
    SM_Tex.links.new(mix_rgb.outputs[0], bsdf.inputs[17]);

    separate_rgb = SM_Tex.nodes.new('ShaderNodeSeparateRGB');
    separate_rgb.location = (-280, -100);
    SM_Tex.links.new(group_input.outputs[3], separate_rgb.inputs[0]);

    if alpha:
        SM_Tex.links.new(separate_rgb.outputs[0], bsdf.inputs[19]);

    math1 = SM_Tex.nodes.new('ShaderNodeMath');
    math1.location = (-109, -208);
    math1.hide = True;
    math1.operation = 'MULTIPLY';
    SM_Tex.links.new(math1.outputs[0], bsdf.inputs[5]);
    SM_Tex.links.new(separate_rgb.outputs[1], math1.inputs[0]);


    math2 = SM_Tex.nodes.new('ShaderNodeMath');
    math2.location = (-285, -273);
    math2.hide = True;
    math2.operation = 'MULTIPLY';
    SM_Tex.links.new(group_input.outputs[4], math2.inputs[0]);
    SM_Tex.links.new(group_input.outputs[6], math2.inputs[1]);

    math3 = SM_Tex.nodes.new('ShaderNodeMath');
    math3.location = (-285, -235);
    math3.hide = True;
    math3.operation = 'MULTIPLY';
    SM_Tex.links.new(group_input.outputs[4], math3.inputs[0]);
    SM_Tex.links.new(group_input.outputs[5], math3.inputs[1]);
    SM_Tex.links.new(math3.outputs[0], math1.inputs[1]);

    math4 = SM_Tex.nodes.new('ShaderNodeMath');
    math4.location = (-116, -254);
    math4.hide = True;
    math4.operation = 'MULTIPLY';
    SM_Tex.links.new(separate_rgb.outputs[2], math4.inputs[0]);
    SM_Tex.links.new(math4.outputs[0], bsdf.inputs[18]);
    SM_Tex.links.new(math2.outputs[0], math4.inputs[1]);

    normal_map = SM_Tex.nodes.new('ShaderNodeNormalMap');
    normal_map.location = (-300, -315);
    SM_Tex.links.new(group_input.outputs[7], normal_map.inputs[1]);
    SM_Tex.links.new(normal_map.outputs[0], bsdf.inputs[20]);

    group_output = SM_Tex.nodes.new('NodeGroupOutput');
    group_output.location = (500, 0);
    SM_Tex.links.new(bsdf.outputs[0], group_output.inputs[0]);

def node_group_exists(name):
    node_groups = bpy.data.node_groups;
    node_amount = len(node_groups);

    for a in range(node_amount):
        cur_group = node_groups[a];

        if cur_group.name_full == name:
            return True;

    return False;

def add_SM_TEX_node_group():
    if not node_group_exists('SM Tex'):
        create_SM_TEX_node_group('SM Tex', False);

    if not node_group_exists('SM Tex Alpha'):
        create_SM_TEX_node_group('SM Tex Alpha', True);

    if not node_group_exists('SM Glass Tex'):
        create_SM_Glass_Tex_node_group();


def check_if_has_node(nodes, name):
    node_amount = len(nodes);

    for a in range(node_amount):
        cur_node = nodes[a];

        if cur_node.name == name:
            return True;

    return False;

def remove_node_links(node_tree, node):
    for out in node.outputs:
        for lnk in out.links:
            node_tree.links.remove(lnk);

def srgb_to_linearrgb(c):
    if   c < 0:       return 0
    elif c < 0.04045: return c/12.92
    else:             return ((c+0.055)/1.055)**2.4

def hex_to_rgb(h,alpha=1):
    r = (h & 0xff0000) >> 16
    g = (h & 0x00ff00) >> 8
    b = (h & 0x0000ff)
    return tuple([srgb_to_linearrgb(c/0xff) for c in (r,g,b)] + [alpha])

class Test_OT_Operator(bpy.types.Operator):
    bl_idname = "view3d.cursor_center";
    bl_label = "Simple Operator";
    bl_description = "Assigns materials automatically";

    def execute(self, context):
        add_SM_TEX_node_group();

        mat_count = len(bpy.data.materials);

        for i in range(mat_count):
            cur_mat = bpy.data.materials[i];

            if not is_material_valid(cur_mat.name_full):
                continue;

            if cur_mat.node_tree == None:
                continue;

            mat_nodes = cur_mat.node_tree.nodes;
            
            if check_if_has_node(mat_nodes, 'SM Tex'):
                continue;

            if check_if_has_node(mat_nodes, 'SM Tex Alpha'):
                continue;

            if check_if_has_node(mat_nodes, 'SM Glass Tex'):
                continue;

            mat_color = cur_mat.name_full[37:43];

            dif_node = None;
            asg_node = None;
            nor_node = None;
            material_output_node = None;

            for a in range(len(mat_nodes)):
                cur_node = mat_nodes[a];

                if cur_node.bl_idname != "ShaderNodeTexImage":
                    continue;

                link_amount = len(cur_node.outputs[0].links);
                for b in range(link_amount):
                    cur_link = cur_node.outputs[0].links[b];

                    cur_link_socket = cur_link.to_socket.name;
                    cur_link_node = cur_link.to_node.name;

                    if cur_link_socket == 'Color' and cur_link_node == 'Normal Map':
                        nor_node = cur_node;
                        break;
                    elif cur_link_socket == 'Base Color' and cur_link_node == 'Principled BSDF':
                        dif_node = cur_node;
                        break;
                    elif cur_link_socket == 'Specular' and cur_link_node == 'Principled BSDF':
                        asg_node = cur_node;
                        break;

            mat_node_amount = len(mat_nodes);
            for a in range(mat_node_amount):
                cur_node = mat_nodes[mat_node_amount - a - 1];
                cnode_name = cur_node.bl_idname;

                if cnode_name == 'ShaderNodeOutputMaterial':
                    if material_output_node == None:
                        material_output_node = cur_node;
                    continue;

                if cnode_name == 'ShaderNodeTexImage':
                    continue;

                cur_mat.node_tree.nodes.remove(cur_node);

            SM_Tex_Shader = mat_nodes.new('ShaderNodeGroup');
            SM_Tex_Shader.node_tree = bpy.data.node_groups['SM Tex'];
            SM_Tex_Shader.location = (100, 300);
            SM_Tex_Shader.name = 'SM Tex';

            SM_Tex_Shader.inputs[2].default_value = hex_to_rgb(int(mat_color, 16));

            if dif_node != None:
                dif_node.location = (-300, 300);
                dif_node.hide = True;
                cur_mat.node_tree.links.new(dif_node.outputs[0], SM_Tex_Shader.inputs[0]);
                cur_mat.node_tree.links.new(dif_node.outputs[1], SM_Tex_Shader.inputs[1]);
            
            if asg_node != None:
                asg_node.location = (-300, 250);
                asg_node.hide = True;
                cur_mat.node_tree.links.new(asg_node.outputs[0], SM_Tex_Shader.inputs[3]);
                cur_mat.node_tree.links.new(asg_node.outputs[1], SM_Tex_Shader.inputs[4]);

            if nor_node != None:
                nor_node.location = (-300, 200);
                nor_node.hide = True;
                cur_mat.node_tree.links.new(nor_node.outputs[0], SM_Tex_Shader.inputs[7]);

            if material_output_node != None:
                cur_mat.node_tree.links.new(SM_Tex_Shader.outputs[0], material_output_node.inputs[0]);

        return {'FINISHED'};